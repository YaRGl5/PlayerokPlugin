"""
Telegram — команда /consultant и главное меню.
"""

import logging
from aiogram import Router
from aiogram.types import Message
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from ..meta import VERSION

logger = logging.getLogger("gpt_consultant.tgbot.handlers")

router = Router()


def _main_kb(enabled: bool = True) -> InlineKeyboardMarkup:
    toggle = "🔴 Выключить" if enabled else "🟢 Включить"
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text=toggle, callback_data="gc:toggle"),
            InlineKeyboardButton(text="⚙️ Настройки", callback_data="gc:settings"),
        ],
        [
            InlineKeyboardButton(text="📖 Вики", callback_data="gc:wiki"),
            InlineKeyboardButton(text="❓ FAQ", callback_data="gc:faq"),
        ],
        [
            InlineKeyboardButton(text="📊 Статистика", callback_data="gc:stats"),
            InlineKeyboardButton(text="🗑 Очистить историю", callback_data="gc:clear"),
        ],
    ])


@router.message(Command("consultant"))
async def cmd_consultant(message: Message):
    """Команда /consultant — управление AI-консультантом."""
    try:
        from ..config import Settings
        config = Settings.get("config")
        enabled = config.get("enabled", True)
        has_key = bool(config.get("api_key", ""))
    except Exception:
        enabled = True
        has_key = False

    status = "🟢 Активен" if enabled else "🔴 Отключён"
    key_status = "✅ Задан" if has_key else "⚠️ Не задан"

    text = (
        f"🤖 **GPT Consultant v{VERSION}**\n\n"
        f"Статус: {status}\n"
        f"API ключ: {key_status}\n\n"
        f"AI-консультант автоматически отвечает\n"
        f"на сообщения покупателей в Playerok чате."
    )
    await message.answer(text, reply_markup=_main_kb(enabled), parse_mode="Markdown")

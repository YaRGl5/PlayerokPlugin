"""
Telegram bot — роутер модуля gpt_consultant.
"""

import logging
from aiogram import Router

logger = logging.getLogger("gpt_consultant.tgbot")

router = Router()

# Handlers
try:
    from .handlers import router as cmd_router
    router.include_router(cmd_router)
except Exception as e:
    logger.error(f"handlers: {e}")

try:
    from .settings_handlers import router as settings_router
    router.include_router(settings_router)
except Exception as e:
    logger.error(f"settings: {e}")

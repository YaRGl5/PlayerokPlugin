"""Инициализация Telegram бота для GPT-консультанта."""

import logging
from ..meta import PREFIX

logger = logging.getLogger("gpt_consultant.tgbot")

_tgbot = None


async def on_telegram_bot_init(tgbot):
    global _tgbot
    _tgbot = tgbot
    logger.info(f"{PREFIX} Telegram бот инициализирован")

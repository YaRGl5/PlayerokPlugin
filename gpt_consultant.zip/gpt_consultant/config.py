import os
from settings import (
    Settings as sett,
    SettingsFile
)

_settings_dir = os.path.join(os.path.dirname(__file__), "module_settings")
os.makedirs(_settings_dir, exist_ok=True)

CONFIG = SettingsFile(
    name="config",
    path=os.path.join(_settings_dir, "config.json"),
    need_restore=True,
    default={
        "enabled": True,
        "api_key": "",
        "model": "llama-3.3-70b-versatile",
        "system_prompt": (
            "Ты — вежливый консультант магазина на Playerok.\n"
            "Отвечай кратко (1-3 предложения), по-русски.\n"
            "Если не знаешь ответ — скажи что передашь вопрос продавцу.\n"
            "Не обсуждай цены — они фиксированные.\n"
            "Не давай скидки."
        ),
        "response_delay": 3.0,
        "batch_wait": 4.0,
        "max_tokens": 300,
        "ignore_keywords": ["ок", "спасибо", "понял", "хорошо", "👍"],
        "admin_chat_ids": [],
        "max_history": 10,
        "auto_respond": True,
    }
)

DATA = [CONFIG]


class Settings:
    @staticmethod
    def get(name: str) -> dict:
        return sett.get(name, DATA)

    @staticmethod
    def set(name: str, new: list | dict) -> dict:
        return sett.set(name, new, DATA)

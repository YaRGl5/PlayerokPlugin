"""FSM-состояния для многошаговых диалогов."""

from aiogram.fsm.state import State, StatesGroup


class ConsultantStates(StatesGroup):
    waiting_api_key = State()
    waiting_prompt = State()
    waiting_wiki = State()
    waiting_faq_question = State()
    waiting_faq_answer = State()
    waiting_delay = State()
    waiting_admin_id = State()
    waiting_escalation = State()
    waiting_ignore = State()
    waiting_model = State()

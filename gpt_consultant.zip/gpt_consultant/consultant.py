"""
Ядро GPT-консультанта — общение с Groq API (Llama 3).
Поддержка: системный промпт, база знаний (вики), история диалогов,
умная эскалация, батчинг сообщений.
"""

import os
import json
import time
import logging
import threading
import requests
from typing import Optional

logger = logging.getLogger("gpt_consultant.engine")

GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions"

# Маркер эскалации — AI добавляет эту строку если не может помочь
ESCALATE_MARKER = "[НУЖЕН_ПРОДАВЕЦ]"


class KnowledgeBase:
    """База знаний: вики + товары + FAQ. Загружается из файлов."""

    def __init__(self, module_dir: str):
        self._dir = os.path.join(module_dir, "knowledge")
        os.makedirs(self._dir, exist_ok=True)
        self._wiki_path = os.path.join(self._dir, "wiki.md")
        self._faq_path = os.path.join(self._dir, "faq.json")

    def get_wiki(self) -> str:
        if os.path.exists(self._wiki_path):
            with open(self._wiki_path, "r", encoding="utf-8") as f:
                return f.read()
        return ""

    def set_wiki(self, text: str):
        with open(self._wiki_path, "w", encoding="utf-8") as f:
            f.write(text)

    def get_faq(self) -> list[dict]:
        if os.path.exists(self._faq_path):
            with open(self._faq_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return []

    def set_faq(self, faq: list[dict]):
        with open(self._faq_path, "w", encoding="utf-8") as f:
            json.dump(faq, f, ensure_ascii=False, indent=2)

    def add_faq(self, question: str, answer: str):
        faq = self.get_faq()
        faq.append({"question": question, "answer": answer})
        self.set_faq(faq)

    def remove_faq(self, index: int):
        faq = self.get_faq()
        if 0 <= index < len(faq):
            faq.pop(index)
            self.set_faq(faq)

    def get_products_text(self) -> str:
        """Получить описание товаров из vouchers/products.json."""
        try:
            products_path = os.path.join(
                os.path.dirname(self._dir), "..", "vouchers", "products.json"
            )
            if os.path.exists(products_path):
                with open(products_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                products = data.get("products", [])
                if products:
                    lines = ["Доступные товары в магазине:"]
                    for p in products:
                        name = p.get("playerok_name", "?")
                        aliases = ", ".join(p.get("playerok_name_aliases", []))
                        line = f"- {name}"
                        if aliases:
                            line += f" (также называется: {aliases})"
                        lines.append(line)
                    return "\n".join(lines)
        except Exception:
            pass
        return ""

    def build_context(self) -> str:
        """Собрать полный контекст для AI."""
        parts = []

        wiki = self.get_wiki()
        if wiki:
            parts.append(f"=== БАЗА ЗНАНИЙ О МАГАЗИНЕ ===\n{wiki}")

        products = self.get_products_text()
        if products:
            parts.append(f"\n=== ТОВАРЫ ===\n{products}")

        faq = self.get_faq()
        if faq:
            faq_text = "\n".join(
                f"В: {item['question']}\nО: {item['answer']}"
                for item in faq
            )
            parts.append(f"\n=== ЧАСТЫЕ ВОПРОСЫ ===\n{faq_text}")

        return "\n\n".join(parts)


class ChatHistory:
    """История диалогов по chat_id (в памяти + файл)."""

    def __init__(self, storage_path: str, max_history: int = 10):
        self._path = storage_path
        self._max = max_history
        self._data: dict[str, list] = {}
        os.makedirs(os.path.dirname(storage_path), exist_ok=True)
        self._load()

    def _load(self):
        if os.path.exists(self._path):
            try:
                with open(self._path, "r", encoding="utf-8") as f:
                    self._data = json.load(f)
            except Exception:
                self._data = {}

    def _save(self):
        try:
            with open(self._path, "w", encoding="utf-8") as f:
                json.dump(self._data, f, ensure_ascii=False)
        except Exception:
            pass

    def add_message(self, chat_id: str, role: str, text: str):
        if chat_id not in self._data:
            self._data[chat_id] = []
        self._data[chat_id].append({
            "role": role,
            "text": text,
            "ts": time.time()
        })
        if len(self._data[chat_id]) > self._max * 2:
            self._data[chat_id] = self._data[chat_id][-self._max * 2:]
        self._save()

    def get_history(self, chat_id: str) -> list[dict]:
        return self._data.get(chat_id, [])[-self._max * 2:]

    def clear(self, chat_id: str = None):
        if chat_id:
            self._data.pop(chat_id, None)
        else:
            self._data = {}
        self._save()


class MessageBatcher:
    """
    Батчинг сообщений: если покупатель шлёт несколько сообщений подряд,
    ждём паузу и объединяем в одно.
    """

    def __init__(self, wait_seconds: float = 4.0):
        self._wait = wait_seconds
        self._buffers: dict[str, list[str]] = {}
        self._contexts: dict[str, set[str]] = {}  # Для хранения контекста (товар, сделка)
        self._timers: dict[str, threading.Timer] = {}
        self._callbacks: dict[str, callable] = {}
        self._lock = threading.Lock()

    def add_message(self, chat_id: str, text: str, ctx: str, callback):
        """Добавить сообщение в буфер. callback вызовется когда пауза истечёт."""
        with self._lock:
            if chat_id in self._timers:
                self._timers[chat_id].cancel()

            if chat_id not in self._buffers:
                self._buffers[chat_id] = []
                self._contexts[chat_id] = set()

            self._buffers[chat_id].append(text)
            if ctx:
                self._contexts[chat_id].add(ctx)

            self._callbacks[chat_id] = callback

            timer = threading.Timer(self._wait, self._flush, args=[chat_id])
            timer.daemon = True
            self._timers[chat_id] = timer
            timer.start()

    def _flush(self, chat_id: str):
        with self._lock:
            messages = self._buffers.pop(chat_id, [])
            contexts = self._contexts.pop(chat_id, set())
            callback = self._callbacks.pop(chat_id, None)
            self._timers.pop(chat_id, None)

        if messages and callback:
            combined_text = "\n".join(messages)
            combined_ctx = "\n".join(contexts) if contexts else ""
            try:
                callback(combined_text, combined_ctx)
            except Exception as e:
                logger.error(f"Batcher callback error: {e}")


class AIConsultant:
    """Основной класс AI-консультанта (Groq API — Llama 3)."""

    def __init__(self, config: dict, knowledge_base: KnowledgeBase,
                 chat_history: ChatHistory):
        self.config = config
        self.kb = knowledge_base
        self.history = chat_history
        self._api_key = config.get("api_key", "")
        self._model = config.get("model", "llama-3.3-70b-versatile")
        self._ready = bool(self._api_key)
        self.batcher = MessageBatcher(
            wait_seconds=config.get("batch_wait", 4.0)
        )

        if self._ready:
            logger.info(f"Groq модель: {self._model}")
        else:
            logger.warning("Groq API ключ не задан")

    def _build_system_prompt(self, chat_context: str = "") -> str:
        """Собрать полный system prompt: роль + база знаний + правила + эскалация + текущий диалог."""
        parts = [self.config.get("system_prompt", "Ты консультант магазина.")]

        if chat_context:
            parts.append(f"=== ТЕКУЩИЙ КОНТЕКСТ ДИАЛОГА ===\n"
                         f"Покупатель находится в чате по поводу:\n{chat_context}")

        context = self.kb.build_context()
        if context:
            parts.append(context)

        parts.append(
            "\n=== ПРАВИЛА ОТВЕТА ===\n"
            "- Отвечай кратко (1-3 предложения)\n"
            "- Используй тот же язык что и покупатель\n"
            "- Не используй markdown разметку (**, ## и тд)\n"
            "- Будь дружелюбным и профессиональным\n"
            "- Если покупатель шлёт несколько сообщений подряд — отвечай на все сразу\n"
            "- НИКОГДА не копируй текст из FAQ или Базы Знаний дословно!\n"
            "  FAQ и Вики — это ШПАРГАЛКА для тебя, а не готовый текст.\n"
            "  Всегда перефразируй информацию своими словами,\n"
            "  адаптируй под конкретный вопрос покупателя.\n"
            "  Каждый ответ должен быть уникальным и живым.\n"
            "\n=== ЭСКАЛАЦИЯ ===\n"
            "Если покупатель описывает проблему, которую ты НЕ МОЖЕШЬ решить "
            "(например: код не работает, нужен возврат, техническая проблема, "
            "спор, жалоба на качество, обвинения) — "
            f"ОБЯЗАТЕЛЬНО добавь маркер {ESCALATE_MARKER} в КОНЦЕ своего ответа.\n"
            "Сначала вежливо ответь покупателю, что передашь вопрос продавцу, "
            f"а потом поставь {ESCALATE_MARKER}.\n"
            f"Если ты МОЖЕШЬ помочь сам — НЕ ставь {ESCALATE_MARKER}.\n"
            "Пример ответа с эскалацией:\n"
            f"\"Понимаю вашу ситуацию. Сейчас передам ваш вопрос продавцу, он поможет разобраться! {ESCALATE_MARKER}\""
        )

        return "\n\n".join(parts)

    def reload(self, config: dict = None):
        if config:
            self.config = config
        self._api_key = self.config.get("api_key", "")
        self._model = self.config.get("model", "llama-3.3-70b-versatile")
        self._ready = bool(self._api_key)
        self.batcher._wait = self.config.get("batch_wait", 4.0)

    def should_ignore(self, text: str) -> bool:
        """Проверить нужно ли игнорировать сообщение."""
        text_lower = text.lower().strip()
        if len(text_lower) < 2:
            return True
        ignore_kw = self.config.get("ignore_keywords", [])
        for kw in ignore_kw:
            if text_lower == kw.lower() or text_lower == kw.lower() + ".":
                return True
        return False

    def generate_response(self, chat_id: str, user_message: str, chat_context: str = "") -> dict:
        """
        Сгенерировать ответ через Groq API.
        Возвращает: {"text": str, "escalate": bool}
        """
        if not self._ready:
            logger.warning("API ключ не задан")
            return {"text": None, "escalate": False}

        try:
            messages = [
                {"role": "system", "content": self._build_system_prompt(chat_context)}
            ]

            # История
            history_msgs = self.history.get_history(chat_id)
            for msg in history_msgs:
                role = "user" if msg["role"] == "user" else "assistant"
                messages.append({"role": role, "content": msg["text"]})

            messages.append({"role": "user", "content": user_message})

            resp = requests.post(
                GROQ_API_URL,
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": self._model,
                    "messages": messages,
                    "max_tokens": self.config.get("max_tokens", 300),
                    "temperature": 0.7,
                },
                timeout=30,
            )

            if resp.status_code != 200:
                logger.error(f"Groq ошибка {resp.status_code}: {resp.text[:200]}")
                return {"text": None, "escalate": False}

            data = resp.json()
            raw_answer = data["choices"][0]["message"]["content"].strip()

            # Проверить маркер эскалации
            escalate = ESCALATE_MARKER in raw_answer
            # Убрать маркер из текста ответа покупателю
            clean_answer = raw_answer.replace(ESCALATE_MARKER, "").strip()

            # Сохранить в историю
            self.history.add_message(chat_id, "user", user_message)
            self.history.add_message(chat_id, "assistant", clean_answer)

            return {"text": clean_answer, "escalate": escalate}

        except Exception as e:
            logger.error(f"Groq ошибка: {e}")

        return {"text": None, "escalate": False}

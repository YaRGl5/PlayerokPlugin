"""
Telegram — настройки и управление GPT-консультантом.
Inline кнопки: toggle, API key, промпт, вики, FAQ, эскалация.
"""

import logging
from aiogram import Router, F
from aiogram.types import CallbackQuery, Message, BufferedInputFile
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext

from .states import ConsultantStates
from ..meta import VERSION

logger = logging.getLogger("gpt_consultant.tgbot.settings")

router = Router()


def _back_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="◀️ Назад", callback_data="gc:menu")]
    ])


def _cancel_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="❌ Отмена", callback_data="gc:settings")]
    ])


# ─── Menu ────────────────────────────────────────────────

@router.callback_query(F.data == "gc:menu")
async def cb_menu(callback: CallbackQuery):
    try:
        from ..config import Settings
        config = Settings.get("config")
        enabled = config.get("enabled", True)
        has_key = bool(config.get("api_key", ""))
    except Exception:
        enabled = True
        has_key = False

    from .handlers import _main_kb
    status = "🟢 Активен" if enabled else "🔴 Отключён"
    key_status = "✅ Задан" if has_key else "⚠️ Не задан"

    await callback.message.edit_text(
        f"🤖 **GPT Consultant v{VERSION}**\n\n"
        f"Статус: {status}\n"
        f"API ключ: {key_status}",
        reply_markup=_main_kb(enabled), parse_mode="Markdown"
    )
    await callback.answer()


# ─── Toggle ──────────────────────────────────────────────

@router.callback_query(F.data == "gc:toggle")
async def cb_toggle(callback: CallbackQuery):
    from ..config import Settings
    config = Settings.get("config")
    config["enabled"] = not config.get("enabled", True)
    Settings.set("config", config)
    state = "включён 🟢" if config["enabled"] else "выключен 🔴"
    await callback.answer(f"Консультант {state}", show_alert=True)
    await cb_menu(callback)


# ─── Settings ────────────────────────────────────────────

@router.callback_query(F.data == "gc:settings")
async def cb_settings(callback: CallbackQuery, state: FSMContext = None):
    if state:
        await state.clear()
    try:
        from ..config import Settings
        config = Settings.get("config")
    except Exception:
        config = {}

    has_key = "✅" if config.get("api_key") else "❌"
    model = config.get("model", "llama-3.3-70b-versatile")
    delay = config.get("response_delay", 3.0)
    batch = config.get("batch_wait", 4.0)
    auto = "Вкл" if config.get("auto_respond", True) else "Выкл"
    ign = ", ".join(config.get("ignore_keywords", [])[:3])

    text = (
        f"⚙️ **Настройки консультанта**\n\n"
        f"🔑 API Key: {has_key}\n"
        f"🤖 Модель: `{model}`\n"
        f"⏱ Батчинг: `{batch}` сек\n"
        f"🔄 Авто-ответ: {auto}\n"
        f"🚨 Эскалация: _AI решает сам_\n"
        f"🚫 Игнор: _{ign}..._"
    )

    buttons = [
        [
            InlineKeyboardButton(text="🔑 API Key", callback_data="gc:s:apikey"),
            InlineKeyboardButton(text="🤖 Модель", callback_data="gc:s:model"),
        ],
        [
            InlineKeyboardButton(text="📝 Промпт", callback_data="gc:s:prompt"),
            InlineKeyboardButton(text="⏱ Батчинг", callback_data="gc:s:batch"),
        ],
        [
            InlineKeyboardButton(text="🔄 Авто-ответ", callback_data="gc:s:autorespond"),
            InlineKeyboardButton(text="👤 Админы", callback_data="gc:s:admins"),
        ],
        [
            InlineKeyboardButton(text="🚫 Игнор-слова", callback_data="gc:s:ignore"),
        ],
        [InlineKeyboardButton(text="◀️ Назад", callback_data="gc:menu")],
    ]

    await callback.message.edit_text(
        text, reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons),
        parse_mode="Markdown"
    )
    await callback.answer()


# ── API Key ──

@router.callback_query(F.data == "gc:s:apikey")
async def cb_api_key(callback: CallbackQuery, state: FSMContext):
    await state.set_state(ConsultantStates.waiting_api_key)
    await callback.message.edit_text(
        "🔑 **Введите Groq API Key:**\n\n"
        "Получить бесплатно: [console.groq.com](https://console.groq.com/keys)\n\n"
        "_Ключ будет сохранён в настройках_",
        reply_markup=_cancel_kb(), parse_mode="Markdown"
    )
    await callback.answer()


@router.message(ConsultantStates.waiting_api_key)
async def on_api_key(message: Message, state: FSMContext):
    key = message.text.strip()
    from ..config import Settings
    config = Settings.get("config")
    config["api_key"] = key
    Settings.set("config", config)

    # Reload consultant
    try:
        from ..plbot.handlers import get_consultant
        c = get_consultant()
        if c:
            c.reload(config)
    except Exception:
        pass

    await state.clear()
    await message.answer(
        f"✅ API Key сохранён: `...{key[-6:]}`",
        reply_markup=_back_kb(), parse_mode="Markdown"
    )


# ── Model ──

@router.callback_query(F.data == "gc:s:model")
async def cb_model(callback: CallbackQuery):
    buttons = [
        [InlineKeyboardButton(text="🧠 llama-3.3-70b (умный)", callback_data="gc:model:llama-3.3-70b-versatile")],
        [InlineKeyboardButton(text="⚡ llama-3.1-8b (быстрый)", callback_data="gc:model:llama-3.1-8b-instant")],
        [InlineKeyboardButton(text="🔀 mixtral-8x7b (сбаланс.)", callback_data="gc:model:mixtral-8x7b-32768")],
        [InlineKeyboardButton(text="◀️ Назад", callback_data="gc:settings")],
    ]
    await callback.message.edit_text(
        "🤖 **Выберите модель:**",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons),
        parse_mode="Markdown"
    )
    await callback.answer()


@router.callback_query(F.data.startswith("gc:model:"))
async def cb_model_set(callback: CallbackQuery):
    model = callback.data.replace("gc:model:", "")
    from ..config import Settings
    config = Settings.get("config")
    config["model"] = model
    Settings.set("config", config)

    try:
        from ..plbot.handlers import get_consultant
        c = get_consultant()
        if c:
            c.reload(config)
    except Exception:
        pass

    await callback.answer(f"✅ Модель: {model}", show_alert=True)
    await cb_settings(callback, None)


# ── Prompt ──

@router.callback_query(F.data == "gc:s:prompt")
async def cb_prompt(callback: CallbackQuery, state: FSMContext):
    from ..config import Settings
    config = Settings.get("config")
    prompt = config.get("system_prompt", "")

    await state.set_state(ConsultantStates.waiting_prompt)
    await callback.message.edit_text(
        f"📝 **Системный промпт**\n\n"
        f"Текущий:\n_{prompt[:300]}_\n\n"
        f"Введите новый промпт (или /skip чтобы оставить):",
        reply_markup=_cancel_kb(), parse_mode="Markdown"
    )
    await callback.answer()


@router.message(ConsultantStates.waiting_prompt)
async def on_prompt(message: Message, state: FSMContext):
    text = message.text.strip()
    if text.lower() == "/skip":
        await state.clear()
        await message.answer("⏭ Оставлен текущий", reply_markup=_back_kb())
        return

    from ..config import Settings
    config = Settings.get("config")
    config["system_prompt"] = text
    Settings.set("config", config)

    try:
        from ..plbot.handlers import get_consultant
        c = get_consultant()
        if c:
            c.reload(config)
    except Exception:
        pass

    await state.clear()
    await message.answer(
        f"✅ Промпт обновлён ({len(text)} символов)",
        reply_markup=_back_kb()
    )


# ── Batch wait ──

@router.callback_query(F.data == "gc:s:batch")
async def cb_batch(callback: CallbackQuery, state: FSMContext):
    await state.set_state(ConsultantStates.waiting_delay)
    await callback.message.edit_text(
        "⏱ **Время ожидания сообщений** (секунды)\n\n"
        "Бот ждёт N секунд перед ответом.\n"
        "Если за это время придут ещё сообщения —\n"
        "все будут объединены в одно.\n\n"
        "Рекомендуется 3-5 сек. Введите число:",
        reply_markup=_cancel_kb(), parse_mode="Markdown"
    )
    await callback.answer()


@router.message(ConsultantStates.waiting_delay)
async def on_batch_wait(message: Message, state: FSMContext):
    try:
        val = float(message.text.strip())
        if val < 1 or val > 30:
            await message.answer("⚠️ Допустимо: 1-30 сек")
            return
    except ValueError:
        await message.answer("⚠️ Введите число")
        return

    from ..config import Settings
    config = Settings.get("config")
    config["batch_wait"] = val
    Settings.set("config", config)

    try:
        from ..plbot.handlers import get_consultant
        c = get_consultant()
        if c:
            c.reload(config)
    except Exception:
        pass

    await state.clear()
    await message.answer(f"✅ Батчинг: {val} сек", reply_markup=_back_kb())


# ── Auto-respond ──

@router.callback_query(F.data == "gc:s:autorespond")
async def cb_autorespond(callback: CallbackQuery):
    from ..config import Settings
    config = Settings.get("config")
    config["auto_respond"] = not config.get("auto_respond", True)
    Settings.set("config", config)
    state = "Вкл ✅" if config["auto_respond"] else "Выкл ❌"
    await callback.answer(f"Авто-ответ: {state}", show_alert=True)
    await cb_settings(callback, None)


# ── Admins ──

@router.callback_query(F.data == "gc:s:admins")
async def cb_admins(callback: CallbackQuery):
    from ..config import Settings
    config = Settings.get("config")
    admin_ids = config.get("admin_chat_ids", [])

    lines = ["👤 **Админы** (для эскалации)\n"]
    if admin_ids:
        for i, aid in enumerate(admin_ids):
            lines.append(f"{i+1}. `{aid}`")
    else:
        lines.append("_Не добавлены_")

    buttons = [
        [InlineKeyboardButton(text="➕ Добавить текущий", callback_data="gc:s:admin_self")],
        [InlineKeyboardButton(text="➕ Ввести ID", callback_data="gc:s:admin_add")],
    ]
    if admin_ids:
        buttons.append([InlineKeyboardButton(text="🗑 Очистить", callback_data="gc:s:admin_clear")])
    buttons.append([InlineKeyboardButton(text="◀️ Назад", callback_data="gc:settings")])

    await callback.message.edit_text(
        "\n".join(lines),
        reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons),
        parse_mode="Markdown"
    )
    await callback.answer()


@router.callback_query(F.data == "gc:s:admin_self")
async def cb_admin_self(callback: CallbackQuery):
    from ..config import Settings
    config = Settings.get("config")
    admin_ids = config.get("admin_chat_ids", [])
    uid = callback.from_user.id
    if uid not in admin_ids:
        admin_ids.append(uid)
        config["admin_chat_ids"] = admin_ids
        Settings.set("config", config)
    await callback.answer(f"✅ Добавлен: {uid}", show_alert=True)
    await cb_admins(callback)


@router.callback_query(F.data == "gc:s:admin_add")
async def cb_admin_add(callback: CallbackQuery, state: FSMContext):
    await state.set_state(ConsultantStates.waiting_admin_id)
    await callback.message.edit_text(
        "Введите Telegram ID:", reply_markup=_cancel_kb()
    )
    await callback.answer()


@router.message(ConsultantStates.waiting_admin_id)
async def on_admin_id(message: Message, state: FSMContext):
    try:
        uid = int(message.text.strip())
    except ValueError:
        await message.answer("⚠️ Введите число")
        return

    from ..config import Settings
    config = Settings.get("config")
    admin_ids = config.get("admin_chat_ids", [])
    if uid not in admin_ids:
        admin_ids.append(uid)
        config["admin_chat_ids"] = admin_ids
        Settings.set("config", config)

    await state.clear()
    await message.answer(f"✅ Добавлен: {uid}", reply_markup=_back_kb())


@router.callback_query(F.data == "gc:s:admin_clear")
async def cb_admin_clear(callback: CallbackQuery):
    from ..config import Settings
    config = Settings.get("config")
    config["admin_chat_ids"] = []
    Settings.set("config", config)
    await callback.answer("✅ Очищено", show_alert=True)
    await cb_admins(callback)




# ── Ignore keywords ──

@router.callback_query(F.data == "gc:s:ignore")
async def cb_ignore(callback: CallbackQuery, state: FSMContext):
    from ..config import Settings
    config = Settings.get("config")
    kw = config.get("ignore_keywords", [])

    await state.set_state(ConsultantStates.waiting_ignore)
    await callback.message.edit_text(
        f"🚫 **Слова для игнора**\n\n"
        f"Текущие: _{', '.join(kw)}_\n\n"
        f"На эти слова AI не отвечает.\n"
        f"Введите слова через запятую:",
        reply_markup=_cancel_kb(), parse_mode="Markdown"
    )
    await callback.answer()


@router.message(ConsultantStates.waiting_ignore)
async def on_ignore(message: Message, state: FSMContext):
    words = [w.strip() for w in message.text.split(",") if w.strip()]
    from ..config import Settings
    config = Settings.get("config")
    config["ignore_keywords"] = words
    Settings.set("config", config)
    await state.clear()
    await message.answer(
        f"✅ Игнор: {', '.join(words)}", reply_markup=_back_kb()
    )


# ─── Wiki ────────────────────────────────────────────────

@router.callback_query(F.data == "gc:wiki")
async def cb_wiki(callback: CallbackQuery):
    try:
        from ..plbot.handlers import get_knowledge_base
        kb = get_knowledge_base()
        wiki = kb.get_wiki() if kb else ""
    except Exception:
        wiki = ""

    preview = wiki[:500] if wiki else "_Пусто_"
    buttons = [
        [InlineKeyboardButton(text="📝 Редактировать", callback_data="gc:wiki:edit")],
        [InlineKeyboardButton(text="📤 Экспорт", callback_data="gc:wiki:export")],
        [InlineKeyboardButton(text="◀️ Назад", callback_data="gc:menu")],
    ]

    await callback.message.edit_text(
        f"📖 **База знаний (Вики)**\n\n{preview}",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons),
        parse_mode="Markdown"
    )
    await callback.answer()


@router.callback_query(F.data == "gc:wiki:edit")
async def cb_wiki_edit(callback: CallbackQuery, state: FSMContext):
    await state.set_state(ConsultantStates.waiting_wiki)
    await callback.message.edit_text(
        "📝 **Введите текст вики:**\n\n"
        "Это ваша база знаний. AI будет использовать её\n"
        "для ответов покупателям.\n\n"
        "Пример:\n"
        "```\n"
        "Мы продаём подарочные карты.\n"
        "Доставка кодом мгновенная.\n"
        "Гарантия — обмен при нерабочем коде.\n"
        "Скидок нет.\n"
        "```\n\n"
        "_Отправьте текст (Markdown поддерживается):_",
        reply_markup=_cancel_kb(), parse_mode="Markdown"
    )
    await callback.answer()


@router.message(ConsultantStates.waiting_wiki)
async def on_wiki(message: Message, state: FSMContext):
    text = message.text.strip()
    try:
        from ..plbot.handlers import get_knowledge_base, get_consultant
        kb = get_knowledge_base()
        if kb:
            kb.set_wiki(text)
        c = get_consultant()
        if c:
            c.reload()
    except Exception as e:
        logger.error(f"Wiki save: {e}")

    await state.clear()
    await message.answer(
        f"✅ Вики обновлена ({len(text)} символов)",
        reply_markup=_back_kb()
    )


@router.callback_query(F.data == "gc:wiki:export")
async def cb_wiki_export(callback: CallbackQuery):
    try:
        from ..plbot.handlers import get_knowledge_base
        kb = get_knowledge_base()
        wiki = kb.get_wiki() if kb else ""
        if not wiki:
            await callback.answer("Вики пуста", show_alert=True)
            return

        doc = BufferedInputFile(
            wiki.encode("utf-8"),
            filename="gpt_wiki.md"
        )
        await callback.message.answer_document(doc, caption="📖 База знаний")
        await callback.answer()
    except Exception as e:
        await callback.answer(f"Ошибка: {e}", show_alert=True)


# ─── FAQ ─────────────────────────────────────────────────

@router.callback_query(F.data == "gc:faq")
async def cb_faq(callback: CallbackQuery):
    try:
        from ..plbot.handlers import get_knowledge_base
        kb = get_knowledge_base()
        faq = kb.get_faq() if kb else []
    except Exception:
        faq = []

    if not faq:
        text = "❓ **FAQ**\n\n_Пусто — добавьте вопросы и ответы_"
    else:
        lines = [f"❓ **FAQ** ({len(faq)})\n"]
        for i, item in enumerate(faq[:10]):
            lines.append(f"{i+1}. **В:** {item['question'][:50]}")
            lines.append(f"   **О:** _{item['answer'][:50]}_\n")
        text = "\n".join(lines)

    buttons = [
        [InlineKeyboardButton(text="➕ Добавить", callback_data="gc:faq:add")],
    ]
    if faq:
        for i in range(min(len(faq), 5)):
            buttons.append([InlineKeyboardButton(
                text=f"🗑 {faq[i]['question'][:25]}",
                callback_data=f"gc:faq:del:{i}"
            )])
    buttons.append([InlineKeyboardButton(text="◀️ Назад", callback_data="gc:menu")])

    await callback.message.edit_text(
        text, reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons),
        parse_mode="Markdown"
    )
    await callback.answer()


@router.callback_query(F.data == "gc:faq:add")
async def cb_faq_add(callback: CallbackQuery, state: FSMContext):
    await state.set_state(ConsultantStates.waiting_faq_question)
    await callback.message.edit_text(
        "➕ **Новый FAQ**\n\nВведите **вопрос:**",
        reply_markup=_cancel_kb(), parse_mode="Markdown"
    )
    await callback.answer()


@router.message(ConsultantStates.waiting_faq_question)
async def on_faq_question(message: Message, state: FSMContext):
    await state.update_data(faq_question=message.text.strip())
    await state.set_state(ConsultantStates.waiting_faq_answer)
    await message.answer(
        f"❓ Вопрос: _{message.text.strip()}_\n\n"
        f"Введите **ответ:**",
        reply_markup=_cancel_kb(), parse_mode="Markdown"
    )


@router.message(ConsultantStates.waiting_faq_answer)
async def on_faq_answer(message: Message, state: FSMContext):
    data = await state.get_data()
    question = data.get("faq_question", "")
    answer = message.text.strip()

    try:
        from ..plbot.handlers import get_knowledge_base, get_consultant
        kb = get_knowledge_base()
        if kb:
            kb.add_faq(question, answer)
        c = get_consultant()
        if c:
            c.reload()
    except Exception as e:
        logger.error(f"FAQ save: {e}")

    await state.clear()
    await message.answer(
        f"✅ FAQ добавлен!\n\n"
        f"**В:** {question}\n**О:** {answer}",
        reply_markup=_back_kb(), parse_mode="Markdown"
    )


@router.callback_query(F.data.startswith("gc:faq:del:"))
async def cb_faq_del(callback: CallbackQuery):
    idx = int(callback.data.split(":")[-1])
    try:
        from ..plbot.handlers import get_knowledge_base, get_consultant
        kb = get_knowledge_base()
        if kb:
            kb.remove_faq(idx)
        c = get_consultant()
        if c:
            c.reload()
    except Exception:
        pass

    await callback.answer("✅ Удалено", show_alert=True)
    await cb_faq(callback)


# ─── Stats ───────────────────────────────────────────────

@router.callback_query(F.data == "gc:stats")
async def cb_stats(callback: CallbackQuery):
    try:
        from ..plbot.handlers import get_chat_history, get_knowledge_base
        ch = get_chat_history()
        kb = get_knowledge_base()

        chats = len(ch._data) if ch else 0
        msgs = sum(len(v) for v in ch._data.values()) if ch else 0
        wiki_len = len(kb.get_wiki()) if kb else 0
        faq_count = len(kb.get_faq()) if kb else 0

        text = (
            f"📊 **Статистика консультанта**\n\n"
            f"💬 Активных чатов: **{chats}**\n"
            f"📨 Сообщений в истории: **{msgs}**\n"
            f"📖 Вики: **{wiki_len}** символов\n"
            f"❓ FAQ: **{faq_count}** записей"
        )
    except Exception as e:
        text = f"📊 **Статистика**\n\n_Ошибка: {e}_"

    await callback.message.edit_text(
        text, reply_markup=_back_kb(), parse_mode="Markdown"
    )
    await callback.answer()


# ─── Clear History ───────────────────────────────────────

@router.callback_query(F.data == "gc:clear")
async def cb_clear(callback: CallbackQuery):
    buttons = [
        [InlineKeyboardButton(text="✅ Да, очистить", callback_data="gc:clear:confirm")],
        [InlineKeyboardButton(text="❌ Нет", callback_data="gc:menu")],
    ]
    await callback.message.edit_text(
        "🗑 **Очистить всю историю диалогов?**\n\n"
        "_AI забудет все прошлые разговоры._",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons),
        parse_mode="Markdown"
    )
    await callback.answer()


@router.callback_query(F.data == "gc:clear:confirm")
async def cb_clear_confirm(callback: CallbackQuery):
    try:
        from ..plbot.handlers import get_chat_history
        ch = get_chat_history()
        if ch:
            ch.clear()
    except Exception:
        pass
    await callback.answer("✅ История очищена", show_alert=True)
    await cb_menu(callback)

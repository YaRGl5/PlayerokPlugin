"""
Обработчики событий Playerok для GPT-консультанта.
Перехватывает NEW_MESSAGE → батчит → отвечает через AI → умная эскалация.
"""

import os
import time
import logging
import threading

from ..meta import PREFIX

logger = logging.getLogger("gpt_consultant.plbot")

# ─── Глобальные ──────────────────────────────────────────

_plbot = None
_consultant = None
_knowledge_base = None
_chat_history = None
_active_deals: set = set()


def get_consultant():
    return _consultant


def get_knowledge_base():
    return _knowledge_base


def get_chat_history():
    return _chat_history


# ─── Инициализация ───────────────────────────────────────

def _init_components():
    global _consultant, _knowledge_base, _chat_history

    module_dir = os.path.dirname(os.path.dirname(__file__))

    from ..consultant import KnowledgeBase, ChatHistory, AIConsultant
    from ..config import Settings

    config = Settings.get("config")

    _knowledge_base = KnowledgeBase(module_dir)
    _chat_history = ChatHistory(
        os.path.join(module_dir, "module_data", "chat_history.json"),
        max_history=config.get("max_history", 10)
    )
    _consultant = AIConsultant(config, _knowledge_base, _chat_history)

    logger.info(f"{PREFIX} Компоненты инициализированы")


# ─── Event Handlers ─────────────────────────────────────

async def on_playerok_bot_init(plbot):
    global _plbot
    _plbot = plbot
    _init_components()
    logger.info(f"{PREFIX} Playerok бот инициализирован")


async def on_new_message(plbot, event):
    """Новое сообщение в чат → батчинг → AI ответ."""
    if _consultant is None:
        return

    try:
        from ..config import Settings
        config = Settings.get("config")
        if not config.get("enabled", True):
            return
        if not config.get("auto_respond", True):
            return
    except Exception:
        return

    try:
        msg = event.message
        chat = event.chat

        chat_id = str(chat.id) if hasattr(chat, 'id') else None
        text = msg.text if hasattr(msg, 'text') and msg.text else None

        sender_id = None
        if hasattr(msg, 'user') and msg.user:
            sender_id = str(msg.user.id) if hasattr(msg.user, 'id') else None

        if not chat_id or not text:
            return

        # Не отвечаем на свои сообщения
        acc = plbot.account if hasattr(plbot, 'account') else plbot
        my_id = str(acc.id) if hasattr(acc, 'id') else None
        if my_id and sender_id == my_id:
            return

        # Не отвечаем на авто-ответы
        if hasattr(msg, 'is_auto_response') and msg.is_auto_response:
            return

        # Не отвечаем если сделка обрабатывается vouchers
        if chat_id in _active_deals:
            return

        # Игнор коротких/служебных
        if _consultant.should_ignore(text):
            return

        logger.info(f"{PREFIX} Получено: [{chat_id[:8]}] {text[:50]}")

        # Контекст сделки/товара
        context_parts = []
        if hasattr(msg, 'item') and msg.item:
            item_name = getattr(msg.item, 'name', '') or getattr(msg.item, 'title', '')
            if item_name:
                context_parts.append(f"Товар: {item_name}")

        if hasattr(msg, 'deal') and msg.deal:
            deal_name = getattr(msg.deal, 'name', '') or getattr(msg.deal, 'title', '')
            if deal_name:
                context_parts.append(f"Сделка: {deal_name}")
                
        ctx_string = " | ".join(context_parts)

        # Батчинг: ждём 4 секунды перед ответом,
        # собираем все сообщения покупателя в одно
        def on_batch_ready(combined_text, combined_ctx):
            _process_and_respond(acc, chat_id, combined_text, sender_id, config, combined_ctx)

        _consultant.batcher.add_message(chat_id, text, ctx_string, on_batch_ready)

    except Exception as e:
        logger.error(f"{PREFIX} Ошибка обработки: {e}", exc_info=True)


def _process_and_respond(acc, chat_id: str, text: str, sender_id: str, config: dict, ctx: str = ""):
    """Генерация ответа + умная эскалация (вызывается из батчера)."""
    try:
        result = _consultant.generate_response(chat_id, text, ctx)

        if result["text"]:
            _send_response(acc, chat_id, result["text"])
            logger.info(f"{PREFIX} Ответ [{chat_id[:8]}]: {result['text'][:60]}...")

            # Отправить лог ответа в TG админу
            _notify_admin_response(chat_id, text, result["text"], sender_id, result["escalate"])

            # Умная эскалация: AI решил что нужен продавец
            if result["escalate"]:
                logger.info(f"{PREFIX} >>> Эскалация! [{chat_id[:8]}]")
        else:
            logger.warning(f"{PREFIX} AI не ответил [{chat_id[:8]}]")

    except Exception as e:
        logger.error(f"{PREFIX} Ошибка генерации: {e}")


async def on_new_deal(plbot, event):
    """Новая сделка — помечаем chat, чтобы не отвечать AI."""
    try:
        deal = event.deal if hasattr(event, 'deal') else event
        chat_id = None
        if hasattr(event, 'chat') and hasattr(event.chat, 'id'):
            chat_id = str(event.chat.id)
        elif hasattr(deal, 'chat_id'):
            chat_id = str(deal.chat_id)
        if chat_id:
            _active_deals.add(chat_id)
    except Exception:
        pass


# ─── Утилиты ────────────────────────────────────────────

def _send_response(acc, chat_id: str, text: str):
    """Отправить сообщение покупателю через Playerok API."""
    try:
        acc.send_message(chat_id, text)
    except Exception as e:
        logger.error(f"{PREFIX} Ошибка отправки: {e}")


def _get_tg_token() -> str:
    """Получить токен Telegram бота из основных настроек."""
    try:
        from settings import Settings as main_sett
        main_config = main_sett.get("config")
        return main_config.get("telegram", {}).get("api", {}).get("token", "")
    except Exception:
        return ""


def _notify_admin_response(chat_id: str, customer_msg: str, bot_response: str,
                           sender_id: str = "", escalated: bool = False):
    """Отправить лог AI-ответа в Telegram админу."""
    try:
        from ..config import Settings
        config = Settings.get("config")
        admin_ids = config.get("admin_chat_ids", [])
        if not admin_ids:
            return

        token = _get_tg_token()
        if not token:
            return

        import requests as req

        if escalated:
            # Срочное уведомление — эскалация
            text = (
                f"🚨 *Эскалация! Нужна помощь!*\n\n"
                f"👤 Покупатель: `{sender_id or '?'}`\n"
                f"💬 Написал:\n_{customer_msg[:200]}_\n\n"
                f"🤖 Бот ответил:\n_{bot_response[:200]}_\n\n"
                f"⚠️ AI не смог помочь — подключись!"
            )
        else:
            # Обычный лог ответа
            text = (
                f"💬 *Диалог с покупателем*\n\n"
                f"👤 `{sender_id or '?'}` написал:\n_{customer_msg[:200]}_\n\n"
                f"🤖 Бот ответил:\n_{bot_response[:200]}_"
            )

        for admin_id in admin_ids:
            try:
                req.post(
                    f"https://api.telegram.org/bot{token}/sendMessage",
                    json={"chat_id": admin_id, "text": text, "parse_mode": "Markdown"},
                    timeout=10
                )
            except Exception:
                pass

    except Exception as e:
        logger.error(f"{PREFIX} Ошибка TG уведомления: {e}")

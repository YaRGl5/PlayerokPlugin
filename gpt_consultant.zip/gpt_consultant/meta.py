from colorama import Fore

PREFIX = f"{Fore.LIGHTGREEN_EX}[gpt-consultant]{Fore.WHITE}"
VERSION = "1.0"
NAME = "gpt_consultant"
DESCRIPTION = "AI-консультант на Google Gemini. Автоматически отвечает на сообщения покупателей в чате Playerok. Поддержка базы знаний, вики, кастомного промпта."
AUTHORS = "@yargl"
LINKS = "https://ai.google.dev/gemini-api"

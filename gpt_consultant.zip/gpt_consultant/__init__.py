"""
GPT Consultant Module — AI-консультант для Playerok.
Автоматически отвечает на сообщения покупателей через Google Gemini API.
Поддержка: база знаний (вики), FAQ, кастомный промпт, эскалация.
"""

from playerokapi.listener.events import EventTypes

# Совместимость с разными версиями playerok-universal
try:
    from core.modules_manager import Module, disable_module
except ImportError:
    try:
        from core.modules import Module, disable_module
    except ImportError:
        class Module:
            def __init__(self):
                self.uuid = None
        async def disable_module(uuid):
            pass

from .plbot.handlers import (
    on_playerok_bot_init,
    on_new_message,
    on_new_deal,
)
from .tgbot import router
from .tgbot._handlers import on_telegram_bot_init
from .meta import *  # noqa: F401, F403

# ─── Module State ────────────────────────────────────────

_module: Module = None


def set_module(module: Module):
    global _module
    _module = module


def get_module():
    return _module


async def on_module_enabled(module: Module):
    try:
        set_module(module)
        print(f"{PREFIX} AI-консультант активен")
    except Exception as e:
        print(f"{PREFIX} Ошибка: {e}")
        await disable_module(_module.uuid)


async def on_module_disabled(module: Module):
    print(f"{PREFIX} Модуль отключен")


# ─── Event Registration ─────────────────────────────────

BOT_EVENT_HANDLERS = {
    "ON_MODULE_ENABLED": [on_module_enabled],
    "ON_MODULE_DISABLED": [on_module_disabled],
    "ON_PLAYEROK_BOT_INIT": [on_playerok_bot_init],
    "ON_TELEGRAM_BOT_INIT": [on_telegram_bot_init],
}

PLAYEROK_EVENT_HANDLERS = {
    EventTypes.NEW_MESSAGE: [on_new_message],
    EventTypes.NEW_DEAL: [on_new_deal],
}

TELEGRAM_BOT_ROUTERS = [router]
